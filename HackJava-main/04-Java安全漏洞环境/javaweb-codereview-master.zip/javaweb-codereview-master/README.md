# javaweb-codereview

`javaweb-codereview`项目是一个演示java代码审计的示例程序，分为多个模块复现各大类常见漏洞的。

文章地址: [Java Web安全-代码审计](JavaSecureCodeReview.md)