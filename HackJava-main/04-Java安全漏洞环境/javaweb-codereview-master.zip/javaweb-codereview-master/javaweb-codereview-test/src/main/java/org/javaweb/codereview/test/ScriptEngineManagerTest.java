package org.javaweb.codereview.test;

/**
 * @author yz
 */
public class ScriptEngineManagerTest {

	public static void main(String[] args) {
		
	}

}
